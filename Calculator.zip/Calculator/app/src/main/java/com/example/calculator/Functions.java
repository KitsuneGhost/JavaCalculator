package com.example.calculator;

import android.widget.EditText;
import android.widget.TextView;

public class Functions {

    boolean arg_is_correct(String arg) { // проверка на пустой аргумент
        return arg.length() != 0;
    }

    float get_arg(EditText etext) { // получает аргумент из EditText
        return Float.parseFloat(etext.getText().toString());
    }

    String get_arg_str(EditText etext) { // получает аргумент в виде строки
        return etext.getText().toString();
    }

    void show_result(TextView vtext, float res) { // выводит результат на экран
        vtext.setText(String.valueOf(res));
    }

    void show_error(TextView vtext, String error) { // выводит текст ошибки на экран
        vtext.setText(error);
    }

}
