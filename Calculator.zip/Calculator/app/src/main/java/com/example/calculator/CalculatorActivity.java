package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CalculatorActivity extends AppCompatActivity {

    private TextView result_TextView; // объявление нужных пременных
    private Button button_plus, button_minus, button_multiply, button_divide, button_pow,
            button_sqrt; // кнопки
    private EditText first_arg_editText, second_arg_edit_Text; // поля ввода
    private boolean first_arg_is_done = false; // флаги
    private boolean second_arg_is_done = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button_plus = findViewById(R.id.button_plus); // тут и далее ниже кнопки сохраняются в переменных
        button_minus = findViewById(R.id.button_minus);
        button_multiply = findViewById(R.id.button_multiply);
        button_divide = findViewById(R.id.button_divide);
        button_pow = findViewById(R.id.button_pow);
        button_sqrt = findViewById(R.id.button_sqrt);
        first_arg_editText = findViewById(R.id.first_arg_editText);
        second_arg_edit_Text = findViewById(R.id.second_arg_editText);
        result_TextView = findViewById(R.id.result_TextView); // текст с результатом вычислений

        Functions functions = new Functions(); // создаем обьект класса Functions

        button_plus.setOnClickListener(new View.OnClickListener() { // обработчик нажатия на плюс
            @Override
            public void onClick(View view) {
                String first_arg_str = functions.get_arg_str(first_arg_editText);
                // получение значения первого аргумента в виде строки
                String second_arg_str = functions.get_arg_str(second_arg_edit_Text);
                // получение значения второго аргумента в виде строки

                first_arg_is_done = functions.arg_is_correct(first_arg_str);
                second_arg_is_done = functions.arg_is_correct(second_arg_str);

                if (first_arg_is_done && second_arg_is_done){
                    // когда все аргументы корректны, начинаем считать
                    float first_arg = functions.get_arg(first_arg_editText);
                    float second_arg = functions.get_arg(second_arg_edit_Text);
                    functions.show_result(result_TextView, first_arg + second_arg); // выводим результат
                    first_arg_is_done = false; // возвращаем флаги к значению false
                    second_arg_is_done = false;
                } else {
                    functions.show_error(result_TextView, "You missed some numbers.");}
            }
        });

        button_minus.setOnClickListener(new View.OnClickListener() { // вычитание
            // аналогично обработке +
            @Override
            public void onClick(View view) {
                String first_arg_str = functions.get_arg_str(first_arg_editText);
                // получение значения первого аргумента в виде строки
                String second_arg_str = functions.get_arg_str(second_arg_edit_Text);
                // получение значения второго аргумента в виде строки

                first_arg_is_done = functions.arg_is_correct(first_arg_str);
                second_arg_is_done = functions.arg_is_correct(second_arg_str);

                if (first_arg_is_done && second_arg_is_done){
                    // когда все аргументы корректны, начинаем считать
                    float first_arg = functions.get_arg(first_arg_editText);
                    float second_arg = functions.get_arg(second_arg_edit_Text);
                    functions.show_result(result_TextView, first_arg - second_arg); // выводим результат
                    first_arg_is_done = false; // возвращаем флаги к значению false
                    second_arg_is_done = false;
                } else {
                    functions.show_error(result_TextView, "You missed some numbers.");}
            }
        });

        button_multiply.setOnClickListener(new View.OnClickListener() { // умножение
            // аналогично обработке плюса
            @Override
            public void onClick(View view) {
                String first_arg_str = functions.get_arg_str(first_arg_editText); // аргумент в виде строки
                String second_arg_str = functions.get_arg_str(second_arg_edit_Text); // аргумент в виде строки

                first_arg_is_done = functions.arg_is_correct(first_arg_str); // проверка аргумента
                second_arg_is_done = functions.arg_is_correct(second_arg_str); // проверка аргумента

                if (first_arg_is_done && second_arg_is_done){
                    // когда все аргументы корректны, начинаем считать
                    float first_arg = functions.get_arg(first_arg_editText);
                    float second_arg = functions.get_arg(second_arg_edit_Text);
                    functions.show_result(result_TextView, first_arg * second_arg); // выводим результат
                    first_arg_is_done = false; // возвращаем флаги к значению false
                    second_arg_is_done = false;
                } else {
                    functions.show_error(result_TextView, "You missed some numbers.");
                }
            }
        });

        button_pow.setOnClickListener(new View.OnClickListener() { // возведение в степень
            // аналогично обработке плюса
            @Override
            public void onClick(View view) {
                String first_arg_str = functions.get_arg_str(first_arg_editText); // аргумент в виде строки
                String second_arg_str = functions.get_arg_str(second_arg_edit_Text); // аргумент в виде строки

                first_arg_is_done = functions.arg_is_correct(first_arg_str); // проверка аргумента
                second_arg_is_done = functions.arg_is_correct(second_arg_str); // проверка аргумента

                if (first_arg_is_done && second_arg_is_done){
                    // когда все аргументы корректны, начинаем считать
                    float first_arg = functions.get_arg(first_arg_editText);
                    float second_arg = functions.get_arg(second_arg_edit_Text);
                    functions.show_result(result_TextView, (float) Math.pow(first_arg, second_arg)); // выводим результат
                    first_arg_is_done = false; // возвращаем флаги к значению false
                    second_arg_is_done = false;
                } else {
                    functions.show_error(result_TextView, "You missed some numbers.");
                }
            }
        });

        button_sqrt.setOnClickListener(new View.OnClickListener() { // корни
            // аналогично обработке плюса, только больше проверок
            @Override
            public void onClick(View view) {
                String first_arg_str = functions.get_arg_str(first_arg_editText); // аргумент в виде строки
                String second_arg_str = functions.get_arg_str(second_arg_edit_Text); // аргумент в виде строки

                first_arg_is_done = functions.arg_is_correct(first_arg_str); // проверка аргумента
                second_arg_is_done = functions.arg_is_correct(second_arg_str); // проверка аргумента

                if (first_arg_is_done && second_arg_is_done){
                    // проверка подкоренного выражения при "четных" корнях
                    float first_arg = functions.get_arg(first_arg_editText);
                    float second_arg = functions.get_arg(second_arg_edit_Text);
                    if (first_arg < 0 && second_arg % 2 == 0){
                        functions.show_error(result_TextView, "Good luck with breaking math rules.");
                        first_arg_is_done = false;
                        second_arg_is_done = false;
                    } else if (second_arg <= 1) { // корни не могут быть отрицательны
                        functions.show_error(result_TextView, "Good try, but this is math error.");
                        second_arg_is_done = false;
                    } else if (second_arg % 1 != 0) {
                        functions.show_error(result_TextView, "This is math error");
                        second_arg_is_done = false;
                    } else if (first_arg_is_done && second_arg_is_done) {
                        float result = (float) Math.pow(first_arg, Math.pow(second_arg, -1));
                        functions.show_result(result_TextView, result);
                        first_arg_is_done = false;
                        second_arg_is_done = false;
                    } else {
                        functions.show_error(result_TextView, "You missed some numbers.");}
                }
            }
        });

        button_divide.setOnClickListener(new View.OnClickListener() { // деление
            // аналогично обработке плюса, но с проверкой на 0
            @Override
            public void onClick(View view) {
                String first_arg_str = functions.get_arg_str(first_arg_editText); // аргумент в виде строки
                String second_arg_str = functions.get_arg_str(second_arg_edit_Text); // аргумент в виде строки

                first_arg_is_done = functions.arg_is_correct(first_arg_str); // проверка аргумента
                second_arg_is_done = functions.arg_is_correct(second_arg_str); // проверка аргумента

                if (first_arg_is_done && second_arg_is_done){
                    // когда все аргументы корректны, начинаем считать
                    float first_arg = functions.get_arg(first_arg_editText);
                    float second_arg = functions.get_arg(second_arg_edit_Text);
                    if (second_arg == 0) {
                        functions.show_error(result_TextView, "Division by 0. Seriously?");
                        second_arg = first_arg;
                    }
                    functions.show_result(result_TextView, first_arg / second_arg); // выводим результат
                    first_arg_is_done = false; // возвращаем флаги к значению false
                    second_arg_is_done = false;
                } else {
                    functions.show_error(result_TextView, "You missed some numbers.");
                }
            }
        });
    }
}
